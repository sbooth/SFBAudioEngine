#pragma once

/* build batch file */
/*
#ifdef APE_BATCH_FILE_VERSION
Set _MA=820
Set _MAV=8.20
#endif
*/

/* major version number */
#define MAC_VERSION_MAJOR 8

/* build version number */
#define MAC_VERSION_REVISION 20

/* leave this so the end of file doesn't get truncated */
