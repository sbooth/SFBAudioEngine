#pragma once

#ifdef WINAMP_VERSION
!define VERSION "7.62"
!define ALT_VER "7_62"
#endif

/* build batch file */
/*
#ifdef APE_BATCH_FILE_VERSION
Set _MA=762
Set _MAV=7.62
#endif
*/

/* major version number */
#define MAC_VERSION_MAJOR 7

/* build version number */
#define MAC_VERSION_REVISION 62

/* leave this so the end of file doesn't get truncated */
